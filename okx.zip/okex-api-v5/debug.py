import datetime

t2 = datetime.datetime.now()
print(t2.utcnow().hour +11 == 1)